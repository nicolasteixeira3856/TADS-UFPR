package exceptions;


public class ErroReceberParametros extends AppException {

    public ErroReceberParametros() {
        super("Erro ao receber os valores listados.");
    }
    
}
