package exceptions;


public class UsuarioSenhaInvalidosException extends AppException {
    public UsuarioSenhaInvalidosException() {
        super("Usuario ou Senha invários.");
    }
    
}

