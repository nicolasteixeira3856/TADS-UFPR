package exceptions;


public class ErroData extends AppException {

    public ErroData() {
        super("Erro ao receber a data.");
    }
    
}
