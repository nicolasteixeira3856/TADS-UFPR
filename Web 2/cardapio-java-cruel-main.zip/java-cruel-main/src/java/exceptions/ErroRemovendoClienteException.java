package exceptions;


public class ErroRemovendoClienteException extends AppException {

    public ErroRemovendoClienteException() {
        super("Erro ao remover o cliente.");
    }
    
}
