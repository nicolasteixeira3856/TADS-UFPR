package exceptions;


public class ErroInserindoClienteException extends AppException {

    public ErroInserindoClienteException() {
        super("Erro ao inserir o cliente.");
    }
    
}
